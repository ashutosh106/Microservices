﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace PaymentWebAPI.Controllers
{
    [ApiController]
    [Route("api/")]
    public class PaymentController : ControllerBase
    {

        [HttpGet(template: "payment")]
        public string Get()
        {
            return "The Payment service";
        }
    }
}